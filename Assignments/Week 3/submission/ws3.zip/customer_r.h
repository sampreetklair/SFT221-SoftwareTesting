// -----------------------------------------------------------
// Name: Sampreet Klair
// Student ID: sklair2@myseneca.ca
// Student Number: 145031225
// Section: ZDD
// -----------------------------------------------------------

#pragma once
#ifndef CUSTOMER_R_H
#define CUSTOMER_R_H

extern "C"
{
#include <customer.h>
}

#endif